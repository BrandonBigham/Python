from django.apps import AppConfig


class FirstProjectConfig(AppConfig):
    name = 'first_project'
