from django.apps import AppConfig


class RandomWordAppConfig(AppConfig):
    name = 'Random_word_app'
