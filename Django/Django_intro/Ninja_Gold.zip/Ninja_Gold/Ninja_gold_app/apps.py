from django.apps import AppConfig


class NinjaGoldAppConfig(AppConfig):
    name = 'Ninja_gold_app'
