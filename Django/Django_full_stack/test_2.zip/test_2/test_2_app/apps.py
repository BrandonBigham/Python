from django.apps import AppConfig


class Test2AppConfig(AppConfig):
    name = 'test_2_app'
